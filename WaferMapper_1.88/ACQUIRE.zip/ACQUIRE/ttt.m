while true
    pause(.1)
    GuiGlobalsStruct.MyCZEMAPIClass.Get_ReturnTypeSingle('AP_WD')*1000
end