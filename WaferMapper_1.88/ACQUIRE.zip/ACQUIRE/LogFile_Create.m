function [IsSuccess] = LogFile_Create(DirectoryForLogFile)
IsSuccess = true;