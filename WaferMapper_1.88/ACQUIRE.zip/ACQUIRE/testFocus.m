%% test Focus stabiltiy

TPN = GetMyDir;



FileName = [TPN sprintf('TestFocus%d',iNum];