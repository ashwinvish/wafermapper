function foo( MyCZEMAPIClass, y )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

;

disp(sprintf('mag = %d, y = %d', MyCZEMAPIClass.GetMag, y));

end

