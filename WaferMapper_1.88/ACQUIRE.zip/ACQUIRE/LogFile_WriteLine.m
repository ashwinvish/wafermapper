function [IsSuccess] = LogFile_WriteLine(LineToWrite, IsPrefixWithTime)

IsSuccess = true;