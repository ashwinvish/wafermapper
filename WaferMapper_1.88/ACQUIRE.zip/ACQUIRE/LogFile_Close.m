function [IsSuccess] = LogFile_Close()
IsSuccess = 1;

