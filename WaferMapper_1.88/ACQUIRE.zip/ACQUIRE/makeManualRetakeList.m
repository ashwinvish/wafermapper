%% Make manual retake list

%%Enter list
manualRetakeList = ...
[3];
%manualRetakeList = sort(manualRetakeList,'ascend')
TPN = GetMyDir;


save([TPN 'manualRetakeList.mat'],'manualRetakeList');